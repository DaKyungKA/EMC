function sum(a, b){
    return a+b;
}
console.log( 'Sum of 2 and 3 is: ' + sum(2, 3) );
