# Installation of willbe

##### Install the package via npm:

```
$ npm i -g willbe
```

#
[Back to content](../README.md)
