function sum(a, b){
    return a+b;
}
console.log( 'Sum of 3 and 7 is: ' + sum(3, 7) );