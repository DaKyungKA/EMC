console.log( 'dir3.test/File.js' );
