console.log( 'dir2/File1.debug.js' );
