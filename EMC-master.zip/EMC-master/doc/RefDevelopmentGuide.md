### Principles

- No full description of routine at the beginning, but short.
