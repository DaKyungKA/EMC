console.log( 'dir3.test/File.test.s' );
