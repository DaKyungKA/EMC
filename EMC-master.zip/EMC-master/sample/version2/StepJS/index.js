function hello(){
    console.log('Hello, world!')
}

module.exports = hello;