function echo()
{
  console.log( 'Exec.js' );
}

module.exports = echo;
