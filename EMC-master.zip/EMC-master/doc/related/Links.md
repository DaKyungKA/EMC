## Useful Links

* [Testing tutorial](https://github.com/Wandalen/wTools/blob/master/doc/junior.introduction.ua.md)
* [Basic module](https://github.com/Wandalen/wTools)
* [Git tutorial](https://learngitbranching.js.org/)
* [Glob tutorial](https://linuxhint.com/bash_globbing_tutorial/)
