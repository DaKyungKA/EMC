console.log( 'Simple.js' );
