function sum(a, b){
    return a+b;
}
console.log( 'File1.debug.js' );
