console.log( 'dir2/File2.debug.js' );
